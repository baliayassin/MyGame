import React, { Component } from 'react'

class MyIdeas extends Component {
    constructor(props) {
        super(props)
    }

    render() {
        return (
            <div>
                These are my ideas: TBD
            </div>
        )
    }
}
export default MyIdeas